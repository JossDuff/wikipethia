# Phase 0 -- The Beacon Chain

## Introduction

This document represents the specification for Phase 0.

```python
def is_active_validator(validator: Validator, epoch: Epoch) -> bool:
    return validator.activation_epoch <= epoch < validator.exit_epoch
```
