---
eip: 1
title: EIP Purpose and Guidelines
author: Martin Becze <mb@ethereum.org>
discussions-to: https://ethereum-magicians.org/t/eip-1/1
status: Living
type: Meta
created: 2015-10-27
---

## What is an EIP?

EIP stands for Ethereum Improvement Proposal.
